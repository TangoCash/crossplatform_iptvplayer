# -*- coding: utf-8 -*-
#QQ.XX.YY.ZZ
#QQ-dodanie nowego hosta
#XX-dodanie nowej funkcjonalnosci
#YY-poprawka dzialania
#ZZ-poprawki kosmetyczne 
#zmiana YY powoduje wyzerowanie ZZ
#zmiana XX powoduje wyzerowanie YY i ZZ
#usunięcie/zablokowanie hosta nie powoduje zmiany QQ
IPTV_VERSION="173.00.09.01"
