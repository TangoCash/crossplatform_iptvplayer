E2emulator emulates openPLi environmet giving chance to run openPLi plugins without massive changes.
It's used by IPTVplayer for Neutrino/KODI/cmdline atm.