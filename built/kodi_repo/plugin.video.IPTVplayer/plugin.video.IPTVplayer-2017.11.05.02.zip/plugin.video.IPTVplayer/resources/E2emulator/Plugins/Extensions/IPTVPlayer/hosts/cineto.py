# -*- coding: utf-8 -*-
###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.dToolsSet.iptvplayerinit import TranslateTXT as _, SetIPTVPlayerLastHostError
from Plugins.Extensions.IPTVPlayer.icomponents.ihost import CHostBase, CBaseHostClass, CDisplayListItem, RetHost, CUrlItem, ArticleContent
from Plugins.Extensions.IPTVPlayer.dToolsSet.iptvtools import printDBG, printExc, GetCookieDir, byteify, rm, GetTmpDir, GetDefaultLang
from Plugins.Extensions.IPTVPlayer.itools.iptvtypes import strwithmeta
###################################################

###################################################
# FOREIGN import
###################################################
import urlparse
import time
import re
import urllib
import string
import random
import base64
import datetime
from copy import deepcopy
from hashlib import md5
try:    import json
except Exception: import simplejson as json
from Components.config import config, ConfigSelection, ConfigYesNo, ConfigText, getConfigListEntry
###################################################


###################################################
# E2 GUI COMMPONENTS 
###################################################
from Plugins.Extensions.IPTVPlayer.icomponents.asynccall import MainSessionWrapper
###################################################

###################################################
# Config options for HOST
###################################################

def GetConfigList():
    optionList = []
    return optionList
###################################################

def gettytul():
    return 'https://cine.to/'

class CineTO(CBaseHostClass):
    
    def __init__(self):
        CBaseHostClass.__init__(self, {'history':'cine.to', 'cookie':'cine.to.cookie', 'cookie_type':'MozillaCookieJar', 'min_py_ver':(2,7,9)})
        self.DEFAULT_ICON_URL = 'https://cine.to/opengraph.jpg'
        self.USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0'
        self.MAIN_URL = 'https://cine.to/'
        self.HEADER = {'User-Agent': self.USER_AGENT, 'DNT':'1', 'Accept': 'text/html', 'Accept-Encoding':'gzip, deflate', 'Referer':self.getMainUrl(), 'Origin':self.getMainUrl()}
        self.AJAX_HEADER = dict(self.HEADER)
        self.AJAX_HEADER.update( {'X-Requested-With': 'XMLHttpRequest', 'Accept-Encoding':'gzip, deflate', 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8', 'Accept':'application/json, text/javascript, */*; q=0.01'} )
        
        self.cacheFilters  = {}
        self.cacheLinks   = {}
        self.defaultParams = {'header':self.HEADER, 'raw_post_data':True, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}
        
        self.MAIN_CAT_TAB = [
                             {'category':'search',                'title': _('Search'),              'search_item':True, },
                             {'category':'search_history',        'title': _('Search history'),                          } 
                            ]
        
    def _getStr(self, item, key, default=''):
        if key not in item: val = default
        if item[key] == None: val = default
        val = str(item[key])
        return self._(val)
    
    def getPage(self, baseUrl, addParams = {}, post_data = None):
        if addParams == {}:
            addParams = dict(self.defaultParams)
        
        origBaseUrl = baseUrl
        baseUrl = self.cm.iriToUri(baseUrl)
        
        def _getFullUrl(url):
            if self.cm.isValidUrl(url):
                return url
            else:
                return urlparse.urljoin(baseUrl, url)
            
        addParams['cloudflare_params'] = {'domain':self.up.getDomain(baseUrl), 'cookie_file':self.COOKIE_FILE, 'User-Agent':self.USER_AGENT, 'full_url_handle':_getFullUrl}
        return self.cm.getPageCFProtection(baseUrl, addParams, post_data)
        
    def _getSearchParams(self, cItem, count=1):
        post_data = {}
        post_data['kind']   = cItem.get('f_kind', 'all')
        post_data['genre']  = cItem.get('f_genres', '0')
        post_data['rating'] = cItem.get('f_rating', '1')
        
        sYear = cItem.get('f_year', self.cacheFilters['year'][-1]['f_year'])
        eYear = cItem.get('f_year', self.cacheFilters['year'][1]['f_year'])
        
        post_data['term'] = cItem.get('f_term', '')
        post_data['page'] = cItem.get('page', 1)
        post_data['count'] = count
        
        post_data = urllib.urlencode(post_data) + '&year%5B%5D={0}&year%5B%5D={1}'.format(sYear, eYear)
        printDBG(post_data)
        return post_data
    
    def listMainMenu(self, cItem, nextCategory):
        self.cacheFilters  = {'kind':[], 'genres':[], 'rating':[], 'year':[]}
        
        sts, data = self.getPage(self.getMainUrl())
        if not sts: return []
        
        try:
            # kind
            tmp = self.cm.ph.getDataBeetwenMarkers(data, '<ul id="kind">', '</ul>')[1]
            tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, '<label', '</label>')
            for item in tmp:
                value = self.cm.ph.getSearchGroups(item, '''value=['"]([^'^"]+?)['"]''')[0]
                title = self.cleanHtmlStr(item)
                self.cacheFilters['kind'].append({'f_kind':value, 'title':title})
            
            # genres
            tmp = self.cm.ph.getDataBeetwenMarkers(data, '<ul id="genres"', '</ul>')[1]
            tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, '<a', '</a>')
            for item in tmp:
                value = self.cm.ph.getSearchGroups(item, '''data-id=['"]([^'^"]+?)['"]''')[0]
                title = self.cleanHtmlStr(item)
                self.cacheFilters['genres'].append({'f_genres':value, 'title':title})
            
            # rating
            for idx in range(10, 0, -1):
                value = str(idx)
                title = _('Rating %s') % idx
                self.cacheFilters['rating'].append({'f_rating':value, 'title':title})
            self.cacheFilters['rating'].insert(0, {'f_rating':1, 'title':_('Any')})
            
            # year
            tmp = self.cm.ph.getDataBeetwenMarkers(data, '<ul id="year"', '</ul>')[1]
            end   = int(self.cm.ph.getSearchGroups(tmp, '''data-end=['"]([0-9]+?)['"]''')[0])
            start = int(self.cm.ph.getSearchGroups(tmp, '''data-start=['"]([0-9]+?)['"]''')[0])
            for idx in range(end, start-1, -1):
                value = str(idx)
                title = _('Year %s') % idx
                self.cacheFilters['year'].append({'f_year':value, 'title':title})
            self.cacheFilters['year'].insert(0, {'title':_('Any')})
        except Exception:
            printExc()
            return
        
        params = dict(cItem)
        params['category'] = nextCategory
        self.listsTab(self.cacheFilters['kind'], params)
        self.listsTab(self.MAIN_CAT_TAB, cItem)
        
    def listGenres(self, cItem, nextCategory):
        printDBG("CineTO.listGenres")
        
        url = self.getFullUrl('/request/search')
        post_data = self._getSearchParams(cItem)
        sts, data = self.getPage(url, post_data=post_data)
        if not sts: return []
        
        cItem = dict(cItem)
        cItem['category'] = nextCategory
        
        try:
            data = byteify(json.loads(data), '', True)['genres']
            for item in self.cacheFilters['genres']:
                params = dict(cItem)
                params.update(item)
                if item['f_genres'] in data:
                    params['title'] = item['title'] + (' (%s)' % data.get(item['f_genres'], '0'))
                self.addDir(params)
        except Exception:
            printExc()
            
    def listRating(self, cItem, nextCategory):
        printDBG("CineTO.listRating")
        
        params = dict(cItem)
        params['category'] = nextCategory
        self.listsTab(self.cacheFilters['rating'], params)
        
    def listYear(self, cItem, nextCategory):
        printDBG("CineTO.listYear")
        
        params = dict(cItem)
        params['category'] = nextCategory
        self.listsTab(self.cacheFilters['year'], params)
            
    def _addItem(self, item, cItem, nextCategory):
        title = self.cleanHtmlStr(item['title'])
        icon  = self.getFullIconUrl(item['cover'])
        descTab = []
        for it in ['year', 'quality', 'language']:
            tmp = item.get(it, '')
            if it == 'language':
                tmp = ', '.join(re.compile('\-([^\,]+?)\,').findall(tmp + ','))
            if tmp != '': descTab.append(tmp)
        desc = ' | '.join(descTab)
        
        params = dict(cItem)
        params.update({'good_for_fav':True, 'title':title, 'imdb':item['imdb'], 'icon':icon, 'desc':desc})
        params['category'] = nextCategory
        self.addDir(params)
        
    def listItems(self, cItem, nextCategory):
        printDBG("CineTO.listItems [%s]" % cItem)
        ITEMS_PER_PAGE = 30
        page = cItem.get('page', 1)
        
        url = self.getFullUrl('/request/search')
        post_data = self._getSearchParams(cItem, count=ITEMS_PER_PAGE)
        sts, data = self.getPage(url, post_data=post_data)
        if not sts: return []
        
        try:
            data = byteify(json.loads(data), noneReplacement='', baseTypesAsString=True)
            for item in data['entries']:
                self._addItem(item, cItem, nextCategory)
        except Exception:
            printExc()

        try:
            if int(data['pages']) > (page + 1): nextPage = True
            else: nextPage = False
        except Exception:
            printExc()
        
        if nextPage:
            params = dict(cItem)
            params.update({'good_for_fav':False, 'title':_("Next page"), 'page':page+1})
            self.addDir(params)
            
    def exploreItem(self, cItem, nextCategory):
        printDBG("CineTO.exploreItem")
        
        url = self.getFullUrl('/request/entry')
        post_data = 'ID=%s' % cItem['imdb']
        
        sts, data = self.getPage(url, post_data=post_data)
        if not sts: return []
        
        try:
            data = byteify(json.loads(data), noneReplacement='', baseTypesAsString=True)['entry']
            icon = self.getFullIconUrl(data.get('cover', cItem.get('icon', '')))
            
            descTab = []
            tmp = data.get('year', '')
            if tmp != '': descTab.append(tmp)
            
            tmp = data.get('duration', '')
            if tmp != '': descTab.append('~%s min.' % tmp)
            
            tmp = data.get('rating', '')
            if tmp != '': descTab.append(tmp)
            
            tmp = ', '.join(data.get('genres', []))
            if tmp != '': descTab.append(tmp)
            
            # move better language at top
            langKeys = list(data['lang'].keys())
            defLang = GetDefaultLang()
            if defLang not in langKeys:
                defLang = 'en'
            if defLang in langKeys:
                langKeys.remove(defLang)
                langKeys.insert(0, defLang)
            
            for langKey in langKeys:
                langName = data['lang'][langKey]
                trailerUrl = data.get('trailer_%s' % langKey, '')
                desc = ' | '.join(descTab) + '[/br]' + data.get('plot_%s' % langKey, '')
                
                if trailerUrl != '':
                    url = 'https://www.youtube.com/watch?v=%s' % trailerUrl
                    title = '[TRAILER] [%s] %s' % (langName, data['title'])
                    params = {'title':title,  'imdb':cItem['imdb'], 'f_lang':langKey, 'url':url, 'icon':icon, 'desc':desc}
                    self.addVideo(params)
                
                title = '[%s] %s (%s)' % (langName, data['title'], data.get('year', ''))
                params = {'title':title, 'imdb':cItem['imdb'], 'f_lang':langKey, 'icon':icon, 'desc':desc}
                self.addVideo(params)
        except Exception:
            printExc()
        
    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("CineTO.listSearchResult cItem[%s], searchPattern[%s] searchType[%s]" % (cItem, searchPattern, searchType))
        cItem = dict(cItem)
        cItem['f_term'] = searchPattern
        self.listItems(cItem, 'explore_item')
        
    def getLinksForVideo(self, cItem):
        printDBG("CineTO.getLinksForVideo [%s]" % cItem)
        retTab = []
        if 1 == self.up.checkHostSupport(cItem.get('url', '')):
            videoUrl = cItem['url'].replace('youtu.be/', 'youtube.com/watch?v=')
            return self.up.getVideoLinkExt(videoUrl)

        cacheKey = 'ID=%s&lang=%s' % (cItem.get('imdb'), cItem.get('f_lang'))
        cacheTab = self.cacheLinks.get(cacheKey, [])
        if len(cacheTab):
            return cacheTab
            
        try:
            url = self.getFullUrl('/request/links')
            post_data = 'ID=%s&lang=%s' % (cItem['imdb'], cItem['f_lang'])
            
            sts, data = self.getPage(url, post_data=post_data)
            if not sts: return []
            
            data = byteify(json.loads(data), '', True)['links']
            printDBG(data)
            
            for hosting in data:
                links = data[hosting]
                if len(links) < 2: continue
                
                quality = links[0]
                for idx in range(1, len(links), 1):
                    name = '[%s] %s' % (quality, hosting)
                    url  = self.getFullUrl('/out/' + links[idx]) 
                    retTab.append({'name':name, 'url':url, 'need_resolve':1})
        except Exception:
            printExc()
        
        if len(retTab):
            self.cacheLinks[cacheKey] = retTab
        
        return retTab
        
    def getVideoLinks(self, videoUrl):
        printDBG("CineTO.getVideoLinks [%s]" % videoUrl)
        videoUrl = strwithmeta(videoUrl)
        urlTab = []
        
        # mark requested link as used one
        if len(self.cacheLinks.keys()):
            for key in self.cacheLinks:
                for idx in range(len(self.cacheLinks[key])):
                    if videoUrl in self.cacheLinks[key][idx]['url']:
                        if not self.cacheLinks[key][idx]['name'].startswith('*'):
                            self.cacheLinks[key][idx]['name'] = '*' + self.cacheLinks[key][idx]['name']
                        break
        try:
            params = dict(self.defaultParams)
            params['return_data'] = False
            sts, response = self.getPage(videoUrl, params)
            videoUrl = response.geturl()
            response.close()
        except Exception:
            printExc()
        
        urlTab = self.up.getVideoLinkExt(videoUrl)
        
        return urlTab
        
    def getArticleContent(self, cItem):
        printDBG("CineTO.getArticleContent [%s]" % cItem)
        retTab = []
        
        otherInfo = {}
        
        url = self.getFullUrl('/request/entry')
        post_data = 'ID=%s' % cItem['imdb']
        
        sts, data = self.getPage(url, post_data=post_data)
        if not sts: return []
        
        title = ''
        desc = ''
        icon = ''
        
        try:
            data = byteify(json.loads(data), noneReplacement='', baseTypesAsString=True)['entry']
            icon = self.getFullIconUrl(data.get('cover', cItem.get('icon', '')))
            title = self.cleanHtmlStr(data['title'])
            
            lang = cItem.get('f_lang', '')
            if lang == '': 
                # move better language at top
                langKeys = list(data['lang'].keys())
                defLang = GetDefaultLang()
                if defLang not in langKeys: defLang = 'en'
                if defLang in langKeys: lang = defLang
                else: lang = langKeys[0]
            
            desc = self.cleanHtmlStr(data.get('plot_'+lang, ''))
            
            tmp = data.get('year', '')
            if tmp != '': otherInfo['year'] = tmp
            
            tmp = data.get('date', '')
            if tmp != '': otherInfo['released'] = tmp
            
            tmp = data.get('duration', '')
            if tmp != '': otherInfo['duration'] = tmp + ' min.'
            
            for item in [('genres', 'genres'), ('producer', 'producers'), ('director', 'directors'), ('actor', 'actors')]:
                tmp = ', '.join(data.get(item[0], []))
                if tmp != '': otherInfo[item[1]] = tmp
            
            tmp = data['rating']
            if tmp != '': otherInfo['imdb_rating'] = '%s/10' % (data['rating'])
            
        except Exception:
            printExc()
            
        if title == '': title = cItem['title']
        if desc == '':  desc = cItem.get('desc', '')
        if icon == '':  icon = cItem.get('icon', self.DEFAULT_ICON_URL)
        
        return [{'title':self.cleanHtmlStr( title ), 'text': self.cleanHtmlStr( desc ), 'images':[{'title':'', 'url':self.getFullUrl(icon)}], 'other_info':otherInfo}]
    
    def handleService(self, index, refresh = 0, searchPattern = '', searchType = ''):
        printDBG('handleService start')
        
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name     = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        mode     = self.currItem.get("mode", '')
        
        printDBG( "handleService: |||||||||||||||||||||||||||||||||||| name[%s], category[%s] " % (name, category) )
        self.currList = []
        
    #MAIN MENU
        if name == None:
            self.listMainMenu({'name':'category'}, 'list_genres')
        elif category == 'list_genres':
            self.listGenres(self.currItem, 'list_rating')
        elif category == 'list_rating':
            self.listRating(self.currItem, 'list_year')
        elif category == 'list_year':
            self.listYear(self.currItem, 'list_items')
        elif category == 'list_items':
            self.listItems(self.currItem, 'explore_item')
        elif category == 'explore_item':
            self.exploreItem(self.currItem, 'list_episodes')
        elif category == 'list_episodes':
            self.listEpisodes(self.currItem, 'explore_item')
    #SEARCH
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item':False, 'name':'category'}) 
            self.listSearchResult(cItem, searchPattern, searchType)
    #HISTORIA SEARCH
        elif category == "search_history":
            self.listsHistory({'name':'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()
        
        CBaseHostClass.endHandleService(self, index, refresh)

class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, CineTO(), True, [])
        
    def withArticleContent(self, cItem):
        if cItem.get('imdb', '') != '':
            return True
        return False
    
    