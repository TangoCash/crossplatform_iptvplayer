# some helper classes first:
class HTMLComponent:
    def produceHTML(self):
        return ""