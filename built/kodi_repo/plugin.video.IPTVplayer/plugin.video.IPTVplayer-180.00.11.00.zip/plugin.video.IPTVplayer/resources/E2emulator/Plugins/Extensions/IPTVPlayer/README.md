# crossplatform_iptvplayer
Please NOTE IPTVdaemon/crossplatform_iptvplayer uses hosts and components from IPTVplayer for E2.(https://gitlab.com/groups/iptvplayer-for-e2)
All creadits go to its author - @sss who manages this great IPTVplayer plugin!!!
IPTVdaemon/crossplatform_iptvplayer works outside e2 and can be used from command prompt, neutrino and KODI.


IPTVdaemon/crossplatform_iptvplayer używa hostów i komponentów ogólnie znanej wtyczki IPTVplayer do E2.(https://gitlab.com/groups/iptvplayer-for-e2)
Jest on dziełem kolegi @sss, który nim zarządza. To dzięki niemu możemy się cieszyć taką wspaniałą wtyczką.

IPTVdaemon/crossplatform_iptvplayer jest rozwiązaniem działającym poza środowiskiem e2 i można nim sterować z linii poleceń, neutrino i KODI.
