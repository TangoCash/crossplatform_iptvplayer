def _(text=""):
  return text